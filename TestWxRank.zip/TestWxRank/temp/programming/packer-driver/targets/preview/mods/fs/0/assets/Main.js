System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, cc, _dec, _class, _crd, ccclass, Main;

  function _inheritsLoose(subClass, superClass) { subClass.prototype = Object.create(superClass.prototype); subClass.prototype.constructor = subClass; _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      cc = _cc;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "be30e4mBy1IHLW/uTC/9YUY", "Main", undefined);

      ccclass = cc._decorator.ccclass;

      _export("Main", Main = (_dec = ccclass('Main'), _dec(_class = /*#__PURE__*/function (_cc$Component) {
        _inheritsLoose(Main, _cc$Component);

        function Main() {
          return _cc$Component.apply(this, arguments) || this;
        }

        var _proto = Main.prototype;

        _proto.onLoad = function onLoad() {
          var node = cc.find('Canvas/Rank');
          node.active = false;
        };

        _proto.setLayerInHierarchy = function setLayerInHierarchy(node, layer) {
          var _this = this;

          node.layer = layer;
          node.children.forEach(function (child) {
            _this.setLayerInHierarchy(child, layer);
          });
        };

        _proto.onToggle = function onToggle(toggle) {
          var node = cc.find('Canvas/Rank');
          node.active = toggle.isChecked;
          var layer = cc.Layers.Enum.UI_2D;
          this.setLayerInHierarchy(node, layer);
        };

        return Main;
      }(cc.Component)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=Main.js.map