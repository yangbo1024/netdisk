System.register(["file:///Users/yangbo/Desktop/temp/TestWxRank/assets/Main.ts"], function (_export, _context) {
  "use strict";

  return {
    setters: [function (_fileUsersYangboDesktopTempTestWxRankAssetsMainTs) {}],
    execute: function () {}
  };
});
//# sourceMappingURL=prerequisite-imports.js.map