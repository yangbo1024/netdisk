System.register(["cce:/internal/x/cc-fu/base", "cce:/internal/x/cc-fu/gfx-webgl", "cce:/internal/x/cc-fu/gfx-webgl2", "cce:/internal/x/cc-fu/profiler", "cce:/internal/x/cc-fu/tween", "cce:/internal/x/cc-fu/2d", "cce:/internal/x/cc-fu/ui"], function (_export, _context) {
  "use strict";

  return {
    setters: [function (_cceInternalXCcFuBase) {
      var _exportObj = {};

      for (var _key in _cceInternalXCcFuBase) {
        if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _cceInternalXCcFuBase[_key];
      }

      _export(_exportObj);
    }, function (_cceInternalXCcFuGfxWebgl) {
      var _exportObj2 = {};

      for (var _key2 in _cceInternalXCcFuGfxWebgl) {
        if (_key2 !== "default" && _key2 !== "__esModule") _exportObj2[_key2] = _cceInternalXCcFuGfxWebgl[_key2];
      }

      _export(_exportObj2);
    }, function (_cceInternalXCcFuGfxWebgl2) {
      var _exportObj3 = {};

      for (var _key3 in _cceInternalXCcFuGfxWebgl2) {
        if (_key3 !== "default" && _key3 !== "__esModule") _exportObj3[_key3] = _cceInternalXCcFuGfxWebgl2[_key3];
      }

      _export(_exportObj3);
    }, function (_cceInternalXCcFuProfiler) {
      var _exportObj4 = {};

      for (var _key4 in _cceInternalXCcFuProfiler) {
        if (_key4 !== "default" && _key4 !== "__esModule") _exportObj4[_key4] = _cceInternalXCcFuProfiler[_key4];
      }

      _export(_exportObj4);
    }, function (_cceInternalXCcFuTween) {
      var _exportObj5 = {};

      for (var _key5 in _cceInternalXCcFuTween) {
        if (_key5 !== "default" && _key5 !== "__esModule") _exportObj5[_key5] = _cceInternalXCcFuTween[_key5];
      }

      _export(_exportObj5);
    }, function (_cceInternalXCcFu2d) {
      var _exportObj6 = {};

      for (var _key6 in _cceInternalXCcFu2d) {
        if (_key6 !== "default" && _key6 !== "__esModule") _exportObj6[_key6] = _cceInternalXCcFu2d[_key6];
      }

      _export(_exportObj6);
    }, function (_cceInternalXCcFuUi) {
      var _exportObj7 = {};

      for (var _key7 in _cceInternalXCcFuUi) {
        if (_key7 !== "default" && _key7 !== "__esModule") _exportObj7[_key7] = _cceInternalXCcFuUi[_key7];
      }

      _export(_exportObj7);
    }],
    execute: function () {}
  };
});
//# sourceMappingURL=cc.js.map