System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, cc, _dec, _class, _crd, ccclass, Main;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      cc = _cc;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "be30e4mBy1IHLW/uTC/9YUY", "Main", undefined);

      ({
        ccclass
      } = cc._decorator);

      _export("Main", Main = (_dec = ccclass('Main'), _dec(_class = class Main extends cc.Component {
        onLoad() {
          let node = cc.find('Canvas/Rank');
          node.active = false;
        }

        setLayerInHierarchy(node, layer) {
          node.layer = layer;
          node.children.forEach(child => {
            this.setLayerInHierarchy(child, layer);
          });
        }

        onToggle(toggle) {
          let node = cc.find('Canvas/Rank');
          node.active = toggle.isChecked;
          let layer = cc.Layers.Enum.UI_2D;
          this.setLayerInHierarchy(node, layer);
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=Main.js.map