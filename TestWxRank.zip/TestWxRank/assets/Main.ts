import * as cc from 'cc';
const { ccclass } = cc._decorator;

@ccclass('Main')
export class Main extends cc.Component {
    onLoad() {
        let node = cc.find('Canvas/Rank')!;
        node.active = false;
    }

    setLayerInHierarchy(node: cc.Node, layer: any) {
        node.layer = layer;
        node.children.forEach((child: cc.Node) => {
            this.setLayerInHierarchy(child, layer);
        });
    }

    onToggle(toggle: cc.Toggle) {
        let node = cc.find('Canvas/Rank')!;
        node.active = toggle.isChecked;
        let layer = cc.Layers.Enum.UI_2D;
        this.setLayerInHierarchy(node, layer);
    }
}
